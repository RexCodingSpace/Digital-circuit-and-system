#include "ALU.h"

void ALU::alu_process()
{

    switch (opcode.read())
    {
    case 0:
        ALU_out.write(rs_data.read() + rt_data.read());
        break;
    case 1:
        ALU_out.write(rs_data.read() * rt_data.read());
        break;
    case 2:
        ALU_out.write(rs_data.read() & rt_data.read());
        break;
    case 3:
        ALU_out.write(~rs_data.read());
        break;
    case 4:
        if (rs_data.read()[15] == 1)
            ALU_out.write(~rs_data.read() + 1);
        else
            ALU_out.write(rs_data.read());
        break;
    case 5:
        if (rs_data.read() > rt_data.read())
            ALU_out.write(rt_data.read());
        else
            ALU_out.write(rs_data.read());
        break;
    case 6:
        ALU_out.write(rs_data.read() << immediate.read());
        break;
    case 7:
        sc_uint<16> IMM = immediate.read();
        int IMM_length = immediate.read().length(); 
        if (IMM[IMM_length-1] == 1)
        {
            // 0b = binary補滿
            IMM.range(15, IMM_length) = 0b1111111111111111;
            // 2's complement
            IMM = -(~IMM + 1);
            ALU_out.write(rs_data.read() + IMM);
        }
        else
            ALU_out.write(rs_data.read() + IMM);
        break;
    }
}