#include "decoder.h"

void decoder::decoder_process()
{
    opcode.write(instruction.read().range(15, 13));
    rs.write(instruction.read().range(12, 9));
    rt.write(instruction.read().range(8, 5));
    immediate.write(instruction.read().range(4, 0));
}
// void decoder::decoder_process() {
//     while (true) {
//         wait(); // 等待instruction信号的变化
//         sc_uint<16> inst = instruction.read();

//         sc_uint<3> opcode_field = inst.range(15, 13);
//         sc_uint<4> rs_field = inst.range(12, 9);
//         sc_uint<4> rt_field = inst.range(8, 5);
//         sc_uint<5> immediate_field = inst.range(4, 0);

//         opcode.write(opcode_field);
//         rs.write(rs_field);
//         rt.write(rt_field);
//         immediate.write(immediate_field);
//     }
// }